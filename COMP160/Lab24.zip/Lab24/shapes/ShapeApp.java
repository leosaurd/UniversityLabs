package shapes;

import javax.swing.*;
/** Main application class to create ShapePanel */
public class ShapeApp{
  /** Main method */
  public static void main(String[] args){
    ShapePanel pnl = new ShapePanel();
    JFrame frm = new JFrame();
    frm.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    frm.add(pnl);
    frm.pack();
    frm.setVisible(true);
    
  }
}